/**
 * @(#)RedisCacheService.java 2017年03月27日
 * Copyright ( c ) 2016 Wonders Information Co., Ltd. All Rights Reserved.
 * <p>
 * This software is the confidential and proprietary information of Wonders
 * Information Co., Ltd. ("Confidential Information").  You shall not disclose
 * such Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Wonders Information
 * Co., Ltd. or a Wonders authorized reseller (the "License Agreement"). Wonders
 * may make changes to the Confidential Information from time to time. Such
 * Confidential Information may contain errors.
 * <p>
 * EXCEPT AS EXPLICITLY SET FORTH IN THE LICENSE AGREEMENT, WONDERS DISCLAIMS ALL
 * WARRANTIES, COVENANTS, REPRESENTATIONS, INDEMNITIES, AND GUARANTEES WITH
 * RESPECT TO SOFTWARE AND DOCUMENTATION, WHETHER EXPRESS OR IMPLIED, WRITTEN OR
 * ORAL, STATUTORY OR OTHERWISE INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A
 * PARTICULAR PURPOSE. WONDERS DOES NOT WARRANT THAT END USER'S USE OF THE
 * SOFTWARE WILL BE UNINTERRUPTED, ERROR FREE OR SECURE.
 * <p>
 * WONDERS SHALL NOT BE LIABLE TO END USER, OR ANY OTHER PERSON, CORPORATION OR
 * ENTITY FOR INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL
 * DAMAGES, OR DAMAGES FOR LOSS OF PROFITS, REVENUE, DATA OR USE, WHETHER IN AN
 * ACTION IN CONTRACT, TORT OR OTHERWISE, EVEN IF WONDERS HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES. WONDERS' TOTAL LIABILITY TO END USER SHALL NOT
 * EXCEED THE AMOUNTS PAID FOR THE WONDERS SOFTWARE BY END USER DURING THE PRIOR
 * TWELVE (12) MONTHS FROM THE DATE IN WHICH THE CLAIM AROSE.  BECAUSE SOME
 * STATES OR JURISDICTIONS DO NOT ALLOW LIMITATION OR EXCLUSION OF CONSEQUENTIAL
 * OR INCIDENTAL DAMAGES, THE ABOVE LIMITATION MAY NOT APPLY TO END USER.
 * <p>
 * Copyright version 1.0
 */
package com.springmvc.service;

public interface RedisCacheService {
	/**
	 * 根据id缓存数据。 参数说明：id和sessionObject不允许为null或空值。 数据库若已存在同名键，则会覆盖掉
	 ***/
	public boolean putSessionObject(String id, Object sessionObject);

	/**
	 * 根据id删除已缓存的数据。 参数说明：id不允许为null和空值
	 ***/
	public boolean clearSessionObject(String id);

	/**
	 * 根据id获取已缓存的缓存数据。 参数说明：id不允许为null和空值
	 ***/
	public Object getsessionObject(String id);
}
